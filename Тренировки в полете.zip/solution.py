from flask import *

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'

@app.route('/')
@app.route('/training/<prof>')
def forming(prof):
    param = {}
    param['prof'] = prof
    return render_template('filik.html', **param)


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')